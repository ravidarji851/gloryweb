<?php $__env->startSection('title','Employe'); ?>
<?php $__env->startSection('content'); ?>

	<div class="bd-content col-lg-6">
        <h3 id="example"><?php echo e(isset($data) ?'Edit' :'Create'); ?> Employe <a href="<?php echo e(route('employe')); ?>">Back</a></h3>
    </div>
	<div class="row col-lg-6 align-items-center">
		<form class="form-control" method="POST" action="<?php if(isset($data)): ?><?php echo e(route('employe.update',['id'=>$data->id])); ?><?php else: ?><?php echo e(route('employe.add')); ?><?php endif; ?>" id="create_blog" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="row col-lg-6">
				<label class="form-label" >Company</label>
				<select class="form-control m-input " name="company_id" id="company_id" >
					<option value="0">Select</option>
					<?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($v->id); ?>"  <?php echo e((isset($data) && $data->company_id == $v->id) ? 'selected': ''); ?>><?php echo e($v->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="row col-lg-6">
				<label>Firstname</label>
				<input type="text"  class="form-control m-input" name="first_name" placeholder="Enter firstname" id="first_name" value="<?php echo e((isset($data)) ? $data->first_name:''); ?>">
				<?php if($errors->has('first_name')): ?> 
					<?php echo e($errors->first('first_name')); ?> 
				<?php endif; ?>
				<!--  -->
			</div>
			<div class="row col-lg-6">
				<label class="form-label" >Lastname</label>
				<input type="text" class="form-control m-input" name="last_name" placeholder="Enter lastname" id="last_name" value="<?php echo e((isset($data)) ? $data->last_name:''); ?>">
				<?php if($errors->has('last_name')): ?> 
					<?php echo e($errors->first('last_name')); ?> 
				<?php endif; ?>
				<!--  -->
			</div>
			<div class="row col-lg-6">
				<label class="form-label">Email</label>
				<input type="text" class="form-control m-input" name="email_address" placeholder="Enter email address" id="email_address" value="<?php echo e((isset($data)) ? $data->email_address:''); ?>">
				<?php if($errors->has('email_address')): ?>
					<?php echo e($errors->first('email_address')); ?>

				<?php endif; ?>
			</div>
			<div class="row col-lg-6">
				<label class="form-label" >Position</label>
				<input type="text" class="form-control m-input" name="position" placeholder="Enter position" id="position" value="<?php echo e((isset($data)) ? $data->position:''); ?>">
				<?php if($errors->has('position')): ?>
					<?php echo e($errors->first('position')); ?>

				<?php endif; ?>
			</div>
			<div class="row col-lg-6">
				<label class="form-label" >City</label>
				<input type="text" class="form-control m-input" name="city" placeholder="Enter city" id="city" value="<?php echo e((isset($data)) ? $data->city:''); ?>">
				<?php if($errors->has('city')): ?>
					<?php echo e($errors->first('city')); ?>

				<?php endif; ?>
			</div>
			<div class="row col-lg-6">
				<label class="form-label" >Country</label>
				<input type="text" class="form-control m-input" name="country" placeholder="Enter country" id="country" value="<?php echo e((isset($data)) ? $data->country:''); ?>">
				<?php if($errors->has('country')): ?>
					<?php echo e($errors->first('country')); ?>

				<?php endif; ?>
			</div>
			<div class="row col-lg-6">
				<label class="form-label" >Status</label>

				<div class="form-check">
					<input type="radio" class="form-check-input" name="status" id="status" value="0" <?php echo e((isset($data) && $data->status=='0') ? 'checked':''); ?>>Active<br>
					<input type="radio" class="form-check-input" name="status" id="status" value="1" <?php echo e((isset($data) && $data->status=='1') ? 'checked':''); ?>>In-Active<br>

					
				</div>
			</div>
			<div class="row col-lg-6">
				<input type="submit" class="form-control col-lg-2">
			</div>
		</form>
	</div>
	

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#create_blog').validate({
			rules:{
				company_id:{
					min:1,
				},
				first_name:{
					required:true,
				},
				last_name:{
					required:true,
				},
				email_address:{
					required:true,
				},	
				position:{
					required:true,
				},	
				city:{
					required:true,
				},	
				country:{
					required:true,
				},	
				status:{
					required:true,
				},	
			},
			messages:{
				company_id:{
					min:'Company is required',
				},
				first_name:{
					required:'Firstname required',
				},
				last_name:{
					required:'Lastname required',
				},
				email_address:{
					required:'Email address required',
				},	
				position:{
					required:'Position required',
				},	
				city:{
					required:'City required',
				},	
				country:{
					required:'Country required',
				},	
				status:{
					required:'Status required',
				},	
			}
		})
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/glory/resources/views/employe/employe_edit.blade.php ENDPATH**/ ?>