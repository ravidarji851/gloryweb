<?php $__env->startSection('title','Blog'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session()->has('error_msg')): ?>
<label style="color:red"><?php echo e(session()->get('error_msg')); ?></label>
<?php endif; ?>
<?php if(session()->has('success_msg')): ?>
<label style="color:green"><?php echo e(session()->get('success_msg')); ?></label>
<?php endif; ?>
<div>
	<a href="<?php echo e(route('home')); ?>">Home</a>	
	<a href="<?php echo e(route('employe.create')); ?>">Add</a>
</div>
<table id="table" class="table table-striped table-bordered" style="width:100%">
    <thead>
        <tr>
			<th>Id</th>
			<th>Blog</th>
			<th>Author</th>
			<th>Action</th>
        </tr>
    </thead>
</table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$("#table").DataTable({
			'serverSide':!0,
			'order':['1','asc'],
			ajax:{
				url:"<?php echo e(route('employe.list')); ?>",
				method:"post",
				dataType:'json',
				data:{token:"<?php echo e(csrf_token()); ?>"},
				headers: {
			        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			    }
			},
		 	"aaSorting": [],
			columns:[
				{data:'id',name:'id'},
				{data:'first_name',name:'first_name',
					render:function(data,type,full,raw){
						return data +' '+full.last_name;
					}
				},
				{data:'email_address',name:'email_address'},
				{data:'id',name:'id',
					render:function(data){
						return '<a href="<?php echo e(route("employe.edit")); ?>/'+data+'">Edit</a>&nbsp;<a href="javascript:void(0)" data-user-id='+data+' class="employe-delete">Delete</a>';
					}

				},

			],
		});
	});
	$(document).on('click',".employe-delete",function(){
		var id=$(this).attr("data-user-id");	
		swal({
			title: 'Are you sure want to delete this?',
	        type: "warning",
	        showCancelButton: true,
	        confirmButtonClass: "btn btn-danger m-btn m-btn--pill m-btn--icon m-btn--air",
	        confirmButtonText: 'Yes',
	        cancelButtonClass: 'btn btn-secondary m-btn m-btn--pill m-btn--icon m-btn--air',
	        cancelButtonText: 'No',
		}).then(function(e){
			if(e==true){
				$.ajax({
	                url:"<?php echo e(route('employe.delete')); ?>",
	                type:'POST',
	                headers:{ 'X-CSRF-Token' : jQuery('meta[name=csrf-token]').attr('content') },
	                dataType:'json',
	                data:{'id':id,_token: '<?php echo e(csrf_token()); ?>'},
	                success:function(response){
	                	var msg = response.msg;
	                    if(response.status=='success'){
				            setTimeout(function() {
				                toastr.options = {
				                    closeButton: true,
				                    progressBar: true,
				                    showMethod: 'slideDown',
				                    timeOut: 4000
				                };
				                toastr.success(msg);
				            }, 1300).then($("#table").DataTable().ajax.reload());
	                    }else{
	                    	setTimeout(function() {
				                toastr.options = {
				                    closeButton: true,
				                    progressBar: true,
				                    showMethod: 'slideDown',
				                    timeOut: 4000
				                };
				                toastr.error(msg);
				            }, 1300);
	                    }
	                },
	                error:function(jqXHR,exception){
	                	var msg = response.msg;
	                	setTimeout(function() {
			                toastr.options = {
			                    closeButton: true,
			                    progressBar: true,
			                    showMethod: 'slideDown',
			                    timeOut: 4000
			                };
			                toastr.error(msg);
			            }, 1300);
	                }
	            });
			}
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/glory/resources/views/employe/employe_list.blade.php ENDPATH**/ ?>